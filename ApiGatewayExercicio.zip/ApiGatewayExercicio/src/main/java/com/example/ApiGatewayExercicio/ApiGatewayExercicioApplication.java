package com.example.ApiGatewayExercicio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiGatewayExercicioApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiGatewayExercicioApplication.class, args);
	}

}
